import { Link } from "@tanstack/react-router";
import { Heart, MessageCircle } from "lucide-react";
import { type Product } from "@/data/products";
import { whatsappOrderUrl, formatINR } from "@/lib/whatsapp";

export function ProductCard({ p }: { p: Product }) {
  return (
    <div className="group luxury-card luxury-card-hover overflow-hidden rounded-2xl">
      <Link to="/product/$id" params={{ id: p.id }} className="relative block aspect-[3/4] overflow-hidden bg-white">
        <img
          src={p.image}
          alt={p.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        {p.tag && (
          <span className={`absolute left-3 top-3 rounded-full px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-white ${p.tag === "new" ? "bg-[color:var(--color-maroon)]" : p.tag === "bestseller" ? "bg-[color:var(--color-gold)] text-[color:var(--color-maroon-deep)]" : "bg-black"}`}>
            {p.tag}
          </span>
        )}
        <button aria-label="Wishlist" className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full bg-white/90 text-[color:var(--color-maroon)] shadow hover:bg-white">
          <Heart className="h-4 w-4" />
        </button>
      </Link>
      <div className="p-4">
        <p className="text-[11px] uppercase tracking-[0.18em] text-[color:var(--color-gold)]">{p.fabric}</p>
        <Link to="/product/$id" params={{ id: p.id }} className="mt-1 block font-display text-lg text-[color:var(--color-charcoal)] line-clamp-1 hover:text-[color:var(--color-maroon)]">
          {p.name}
        </Link>
        <div className="mt-2 flex items-baseline gap-2">
          <span className="font-semibold text-[color:var(--color-maroon)]">{formatINR(p.price)}</span>
          {p.oldPrice && <span className="text-xs text-muted-foreground line-through">{formatINR(p.oldPrice)}</span>}
        </div>
        <a
          href={whatsappOrderUrl(p.name, p.price)}
          target="_blank"
          rel="noreferrer"
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-full bg-[#25D366] py-2 text-sm font-medium text-white transition-transform hover:scale-[1.02]"
        >
          <MessageCircle className="h-4 w-4" /> Order on WhatsApp
        </a>
      </div>
    </div>
  );
}