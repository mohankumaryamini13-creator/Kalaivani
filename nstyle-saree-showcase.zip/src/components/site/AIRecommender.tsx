import { useMemo, useState } from "react";
import { Sparkles } from "lucide-react";
import { products, type Product } from "@/data/products";
import { ProductCard } from "./ProductCard";

const occasions = ["wedding","reception","party","cocktail","engagement","sangeet","festive","temple","casual","office"];
const budgets = [
  { label: "Under ₹5,000", max: 5000 },
  { label: "₹5,000 – ₹10,000", min: 5000, max: 10000 },
  { label: "₹10,000 – ₹20,000", min: 10000, max: 20000 },
  { label: "₹20,000+", min: 20000 },
];

export function AIRecommender() {
  const [occasion, setOccasion] = useState("wedding");
  const [budgetIdx, setBudgetIdx] = useState(1);
  const [picked, setPicked] = useState<Product[] | null>(null);

  const compute = () => {
    const b = budgets[budgetIdx];
    const list = products.filter(p => p.occasions.includes(occasion))
      .filter(p => (b.min == null || p.price >= b.min) && (b.max == null || p.price <= b.max));
    setPicked((list.length ? list : products).slice(0, 4));
  };

  const initial = useMemo(() => products.slice(0, 4), []);
  const list = picked ?? initial;

  return (
    <section className="relative bg-gradient-to-br from-[color:var(--color-maroon-deep)] via-[color:var(--color-maroon)] to-[color:var(--color-maroon-deep)] py-20 text-[color:var(--color-ivory)]">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full border border-[color:var(--color-gold)]/40 bg-black/20 px-4 py-1.5 text-xs uppercase tracking-widest text-[color:var(--color-gold)]">
            <Sparkles className="h-3.5 w-3.5" /> AI Saree Recommender
          </span>
          <h2 className="mt-4 font-display text-4xl md:text-5xl gold-gradient-text">Find Your Perfect Drape</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-[color:var(--color-ivory)]/80">Tell us the occasion and your budget — we'll curate sarees just for you.</p>
        </div>
        <div className="mt-10 grid grid-cols-1 gap-6 rounded-2xl border border-[color:var(--color-gold)]/30 bg-black/20 p-6 backdrop-blur md:grid-cols-3">
          <div>
            <label className="brand-font text-xs text-[color:var(--color-gold)]">Occasion</label>
            <select value={occasion} onChange={e => setOccasion(e.target.value)} className="mt-2 w-full rounded-md border border-[color:var(--color-gold)]/30 bg-black/30 px-3 py-2 text-sm capitalize text-white outline-none focus:border-[color:var(--color-gold)]">
              {occasions.map(o => <option key={o} value={o} className="bg-[color:var(--color-maroon-deep)]">{o}</option>)}
            </select>
          </div>
          <div>
            <label className="brand-font text-xs text-[color:var(--color-gold)]">Budget</label>
            <select value={budgetIdx} onChange={e => setBudgetIdx(Number(e.target.value))} className="mt-2 w-full rounded-md border border-[color:var(--color-gold)]/30 bg-black/30 px-3 py-2 text-sm text-white outline-none focus:border-[color:var(--color-gold)]">
              {budgets.map((b, i) => <option key={i} value={i} className="bg-[color:var(--color-maroon-deep)]">{b.label}</option>)}
            </select>
          </div>
          <div className="flex items-end">
            <button onClick={compute} className="btn-gold w-full rounded-full py-3 text-sm uppercase">
              Recommend Sarees
            </button>
          </div>
        </div>
        <div className="mt-10 grid grid-cols-2 gap-6 md:grid-cols-4">
          {list.map(p => <ProductCard key={p.id} p={p} />)}
        </div>
      </div>
    </section>
  );
}