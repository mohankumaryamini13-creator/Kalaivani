import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { Menu, X, Search, Heart } from "lucide-react";
import { Logo } from "./Logo";

const links = [
  { to: "/", label: "Home" },
  { to: "/collections", label: "Collections" },
  { to: "/about", label: "About" },
  { to: "/contact", label: "Contact" },
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b border-[color:var(--color-gold)]/30 bg-[color:var(--color-ivory)]/85 backdrop-blur-md">
      <div className="mx-auto flex h-20 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Logo />
        <nav className="hidden items-center gap-10 md:flex">
          {links.map(l => (
            <Link
              key={l.to}
              to={l.to}
              activeOptions={{ exact: l.to === "/" }}
              activeProps={{ className: "text-[color:var(--color-maroon)]" }}
              className="relative text-sm font-medium uppercase tracking-[0.15em] text-[color:var(--color-charcoal)] transition-colors hover:text-[color:var(--color-maroon)] after:absolute after:-bottom-1.5 after:left-0 after:h-px after:w-0 after:bg-[color:var(--color-gold)] after:transition-all hover:after:w-full"
            >
              {l.label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <button aria-label="Search" className="hidden rounded-full p-2 text-[color:var(--color-maroon)] hover:bg-[color:var(--color-accent)]/40 sm:inline-flex">
            <Search className="h-5 w-5" />
          </button>
          <button aria-label="Wishlist" className="hidden rounded-full p-2 text-[color:var(--color-maroon)] hover:bg-[color:var(--color-accent)]/40 sm:inline-flex">
            <Heart className="h-5 w-5" />
          </button>
          <button onClick={() => setOpen(o => !o)} className="rounded-full p-2 text-[color:var(--color-maroon)] hover:bg-[color:var(--color-accent)]/40 md:hidden" aria-label="Menu">
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      {open && (
        <div className="border-t border-[color:var(--color-gold)]/30 bg-[color:var(--color-ivory)] md:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col px-6 py-4">
            {links.map(l => (
              <Link key={l.to} to={l.to} onClick={() => setOpen(false)} className="py-3 text-sm font-medium uppercase tracking-[0.15em] text-[color:var(--color-charcoal)]">
                {l.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}