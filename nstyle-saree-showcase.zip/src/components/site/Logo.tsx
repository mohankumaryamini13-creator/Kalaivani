import { Link } from "@tanstack/react-router";

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="group flex items-center gap-3">
      <div className="relative flex h-11 w-11 items-center justify-center rounded-full border border-[color:var(--color-gold)] bg-gradient-to-br from-[color:var(--color-maroon)] to-[color:var(--color-maroon-deep)] shadow-[0_4px_20px_-6px_rgba(109,7,26,0.6)]">
        <span className="brand-font text-xl font-bold text-[color:var(--color-gold-light)]">N</span>
        <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-[color:var(--color-gold)]" />
      </div>
      <div className="flex flex-col leading-none">
        <span className={`brand-font text-[15px] font-semibold ${light ? "text-[color:var(--color-ivory)]" : "text-[color:var(--color-maroon)]"}`}>
          N STYLE SAREES
        </span>
        <span className={`mt-1 font-display italic text-[11px] tracking-wide ${light ? "text-[color:var(--color-gold-light)]" : "text-[color:var(--color-gold)]"}`}>
          Western Wear Sarees
        </span>
      </div>
    </Link>
  );
}