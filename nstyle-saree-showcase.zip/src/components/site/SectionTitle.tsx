export function SectionTitle({ eyebrow, title, subtitle, center = true }: { eyebrow?: string; title: string; subtitle?: string; center?: boolean }) {
  return (
    <div className={`${center ? "text-center" : ""} mb-12`}>
      {eyebrow && <p className="brand-font text-xs font-semibold text-[color:var(--color-gold)]">{eyebrow}</p>}
      <h2 className="mt-2 font-display text-3xl text-[color:var(--color-maroon)] sm:text-4xl md:text-5xl">{title}</h2>
      <div className={`mt-4 ${center ? "mx-auto" : ""} h-px w-24 bg-gradient-to-r from-transparent via-[color:var(--color-gold)] to-transparent`} />
      {subtitle && <p className="mx-auto mt-4 max-w-2xl text-sm text-muted-foreground sm:text-base">{subtitle}</p>}
    </div>
  );
}