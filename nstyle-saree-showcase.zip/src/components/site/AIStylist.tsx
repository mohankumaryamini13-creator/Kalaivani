import { useState } from "react";
import { Wand2 } from "lucide-react";

const tipsByColor: Record<string, { blouse: string[]; jewellery: string[]; tips: string[] }> = {
  maroon: {
    blouse: ["Antique gold brocade boat-neck", "Embellished velvet sweetheart neckline", "Sheer net high-neck with zardozi"],
    jewellery: ["Temple-cut gold choker with matching jhumkas", "Polki necklace + maang tikka", "Layered gold haar with pearls"],
    tips: ["Pair with bold red lips and kohl eyes", "Add a maang tikka for a regal bridal vibe", "Choose gold heels to elongate the drape"],
  },
  green: {
    blouse: ["Contrast pink raw-silk elbow-sleeve", "Gold tissue puff-sleeve blouse", "Embroidered cape blouse in ivory"],
    jewellery: ["Emerald + pearl long haar", "Kundan jhumkas with green stones", "Gold bangles stacked with green glass"],
    tips: ["Smokey bronze eye balances emerald tones", "Soft waves over an updo elevates the look", "Add a gajra to the braid for festive flair"],
  },
  pink: {
    blouse: ["Mint contrast embroidered blouse", "Rose-gold sequin halter blouse", "Pastel ivory thread-work blouse"],
    jewellery: ["Rose-gold diamond choker", "Pearl drops + delicate ring set", "Statement floral earrings"],
    tips: ["Soft glam makeup with peach lips works best", "A loose side braid keeps it feminine", "Pair with strappy nude heels"],
  },
  blue: {
    blouse: ["Silver embellished sweetheart blouse", "Navy velvet full-sleeve blouse", "Mirror-work cropped blouse"],
    jewellery: ["Oxidised silver layered necklace", "Crystal chandelier earrings", "Statement silver kada"],
    tips: ["Berry lips contrast beautifully with navy", "Slick back hair into a low bun", "Silver clutch + heels complete the look"],
  },
  default: {
    blouse: ["Contrast gold brocade blouse", "Embellished sweetheart neckline", "Sheer net full-sleeve blouse"],
    jewellery: ["Statement choker with jhumkas", "Layered haar with pearls", "Bold ear cuffs"],
    tips: ["Match metals to your saree's zari", "Carry a clutch in a complementary tone", "Hair: middle-parted bun with a fresh flower"],
  },
};

const palette = [
  { key: "maroon", label: "Maroon / Red", color: "#6D071A" },
  { key: "green", label: "Green", color: "#0F5132" },
  { key: "pink", label: "Pink / Peach", color: "#F4B6C2" },
  { key: "blue", label: "Blue / Navy", color: "#1E3A8A" },
  { key: "default", label: "Other", color: "#C9A84C" },
];

export function AIStylist() {
  const [color, setColor] = useState("maroon");
  const data = tipsByColor[color] ?? tipsByColor.default;
  return (
    <section className="bg-[color:var(--color-ivory)] py-20">
      <div className="mx-auto max-w-7xl px-6">
        <div className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-[color:var(--color-maroon)]/10 px-4 py-1.5 text-xs uppercase tracking-widest text-[color:var(--color-maroon)]">
            <Wand2 className="h-3.5 w-3.5" /> AI Fashion Stylist
          </span>
          <h2 className="mt-4 font-display text-4xl text-[color:var(--color-maroon)] md:text-5xl">Style It Like A Pro</h2>
          <p className="mx-auto mt-3 max-w-xl text-sm text-muted-foreground">Pick your saree tone and get curated styling suggestions.</p>
        </div>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          {palette.map(p => (
            <button key={p.key} onClick={() => setColor(p.key)} className={`flex items-center gap-2 rounded-full border px-4 py-2 text-sm transition-all ${color === p.key ? "border-[color:var(--color-gold)] bg-white shadow-md" : "border-transparent bg-white/60 hover:bg-white"}`}>
              <span className="h-4 w-4 rounded-full ring-1 ring-black/10" style={{ background: p.color }} />
              {p.label}
            </button>
          ))}
        </div>
        <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-3">
          {[
            { title: "Matching Blouses", items: data.blouse },
            { title: "Jewellery Pairing", items: data.jewellery },
            { title: "Styling Tips", items: data.tips },
          ].map(c => (
            <div key={c.title} className="luxury-card rounded-2xl p-6">
              <h3 className="font-display text-xl text-[color:var(--color-maroon)]">{c.title}</h3>
              <div className="mt-2 h-px w-12 bg-[color:var(--color-gold)]" />
              <ul className="mt-4 space-y-3 text-sm text-[color:var(--color-charcoal)]">
                {c.items.map((it, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 flex-none rounded-full bg-[color:var(--color-gold)]" />
                    <span>{it}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}