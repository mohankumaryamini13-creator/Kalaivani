import { Link } from "@tanstack/react-router";
import { Instagram, Phone, Mail, MapPin } from "lucide-react";
import { Logo } from "./Logo";
import { BRAND_ADDRESS, BRAND_EMAIL, BRAND_INSTAGRAM, BRAND_PHONE } from "@/lib/whatsapp";

export function Footer() {
  return (
    <footer className="relative mt-24 bg-gradient-to-b from-[color:var(--color-maroon-deep)] to-black text-[color:var(--color-ivory)]">
      <div className="gold-divider" />
      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-12 px-6 py-16 md:grid-cols-4">
        <div className="space-y-4">
          <Logo light />
          <p className="text-sm leading-relaxed text-[color:var(--color-gold-light)]/80">
            Elegant · Trendy · Unique. Curated luxury sarees from Chennai's modern boutique.
          </p>
        </div>
        <div>
          <h4 className="brand-font mb-4 text-sm text-[color:var(--color-gold)]">Explore</h4>
          <ul className="space-y-2 text-sm">
            <li><Link to="/" className="hover:text-[color:var(--color-gold)]">Home</Link></li>
            <li><Link to="/collections" className="hover:text-[color:var(--color-gold)]">Collections</Link></li>
            <li><Link to="/about" className="hover:text-[color:var(--color-gold)]">About Us</Link></li>
            <li><Link to="/contact" className="hover:text-[color:var(--color-gold)]">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="brand-font mb-4 text-sm text-[color:var(--color-gold)]">Contact</h4>
          <ul className="space-y-3 text-sm text-[color:var(--color-ivory)]/90">
            <li className="flex items-start gap-2"><MapPin className="mt-0.5 h-4 w-4 text-[color:var(--color-gold)]" /> {BRAND_ADDRESS}</li>
            <li className="flex items-center gap-2"><Phone className="h-4 w-4 text-[color:var(--color-gold)]" /> {BRAND_PHONE}</li>
            <li className="flex items-center gap-2"><Mail className="h-4 w-4 text-[color:var(--color-gold)]" /> {BRAND_EMAIL}</li>
          </ul>
        </div>
        <div>
          <h4 className="brand-font mb-4 text-sm text-[color:var(--color-gold)]">Follow</h4>
          <a href={`https://instagram.com/${BRAND_INSTAGRAM}`} target="_blank" rel="noreferrer" className="inline-flex items-center gap-2 text-sm hover:text-[color:var(--color-gold)]">
            <Instagram className="h-4 w-4" /> @{BRAND_INSTAGRAM}
          </a>
          <p className="mt-6 font-display italic text-sm text-[color:var(--color-gold-light)]/80">
            "Thank you for supporting my small business" ♡
          </p>
          <p className="mt-1 text-xs text-[color:var(--color-ivory)]/60">— Kalaivani N, Founder</p>
        </div>
      </div>
      <div className="border-t border-[color:var(--color-gold)]/20 py-5 text-center text-xs text-[color:var(--color-ivory)]/60">
        © {new Date().getFullYear()} N Style Sarees. All rights reserved.
      </div>
    </footer>
  );
}