import bridal1 from "@/assets/saree-bridal-1.jpg";
import silk1 from "@/assets/saree-silk-1.jpg";
import silk2 from "@/assets/saree-silk-2.jpg";
import designer1 from "@/assets/saree-designer-1.jpg";
import designer2 from "@/assets/saree-designer-2.jpg";
import party1 from "@/assets/saree-party-1.jpg";
import cotton1 from "@/assets/saree-cotton-1.jpg";
import western1 from "@/assets/saree-western-1.jpg";

export const categories = [
  { slug: "silk", name: "Silk Sarees", description: "Pure silk woven heritage." },
  { slug: "cotton", name: "Cotton Sarees", description: "Soft, breathable handlooms." },
  { slug: "bridal", name: "Bridal Sarees", description: "Heirloom-worthy bridal couture." },
  { slug: "designer", name: "Designer Sarees", description: "Contemporary statement pieces." },
  { slug: "party", name: "Party Wear Sarees", description: "Glamour for every celebration." },
  { slug: "western", name: "Western Wear Sarees", description: "Indo-western fusion drapes." },
] as const;

export type CategorySlug = (typeof categories)[number]["slug"];

export interface Product {
  id: string;
  name: string;
  category: CategorySlug;
  price: number;
  oldPrice?: number;
  color: string;
  fabric: string;
  image: string;
  gallery: string[];
  description: string;
  tag?: "new" | "bestseller" | "limited";
  occasions: string[];
}

const pool = [bridal1, silk1, silk2, designer1, designer2, party1, cotton1, western1];

export const products: Product[] = [
  { id: "ns-001", name: "Royal Maroon Banarasi Silk", category: "bridal", price: 18999, oldPrice: 24999, color: "Maroon", fabric: "Pure Banarasi Silk", image: bridal1, gallery: [bridal1, silk1, designer2], description: "An heirloom Banarasi drape in deep maroon, woven with intricate gold zari motifs. A timeless choice for the modern bride.", tag: "bestseller", occasions: ["wedding","reception","festive"] },
  { id: "ns-002", name: "Emerald Kanjivaram Silk", category: "silk", price: 14500, color: "Emerald Green", fabric: "Kanjivaram Silk", image: silk1, gallery: [silk1, silk2, bridal1], description: "Lustrous Kanjivaram silk with a contrast gold border. Crafted by master weavers in Tamil Nadu.", tag: "bestseller", occasions: ["wedding","festive","temple"] },
  { id: "ns-003", name: "Blush Pink Designer Georgette", category: "designer", price: 8999, oldPrice: 11999, color: "Blush Pink", fabric: "Pure Georgette", image: designer1, gallery: [designer1, silk2, party1], description: "Featherlight georgette adorned with hand-set sequins and a scalloped gold border.", tag: "new", occasions: ["engagement","reception","cocktail"] },
  { id: "ns-004", name: "Midnight Navy Party Drape", category: "party", price: 7499, color: "Navy Blue", fabric: "Chiffon", image: party1, gallery: [party1, designer1, western1], description: "A flowing chiffon saree with silver thread embroidery — designed for the spotlight.", tag: "new", occasions: ["party","cocktail","reception"] },
  { id: "ns-005", name: "Ivory Handloom Cotton", category: "cotton", price: 3499, color: "Ivory", fabric: "Pure Handloom Cotton", image: cotton1, gallery: [cotton1, silk1, bridal1], description: "Effortless ivory cotton with a fine zari border. Lightweight comfort for everyday elegance.", occasions: ["casual","office","daywear"] },
  { id: "ns-006", name: "Onyx Indo-Western Drape", category: "western", price: 9999, oldPrice: 12999, color: "Black & Rose Gold", fabric: "Crepe Silk", image: western1, gallery: [western1, designer1, party1], description: "Pre-draped indo-western saree with a structured cape blouse. A modern statement piece.", tag: "limited", occasions: ["party","cocktail","reception"] },
  { id: "ns-007", name: "Peach Bloom Silk", category: "silk", price: 11999, color: "Peach", fabric: "Soft Silk", image: silk2, gallery: [silk2, silk1, designer1], description: "Soft peach silk with floral gold weaves — softness meets opulence.", occasions: ["festive","reception","engagement"] },
  { id: "ns-008", name: "Wine Sheer Designer Net", category: "designer", price: 10499, color: "Wine", fabric: "Net with Lining", image: designer2, gallery: [designer2, bridal1, party1], description: "Sheer net saree with delicate stone work in a rich wine hue.", tag: "new", occasions: ["party","cocktail","sangeet"] },
  { id: "ns-009", name: "Crimson Couture Bridal", category: "bridal", price: 26999, oldPrice: 32999, color: "Crimson Red", fabric: "Raw Silk", image: bridal1, gallery: [bridal1, designer2, silk1], description: "Hand-embroidered bridal masterpiece with antique zardozi work.", tag: "limited", occasions: ["wedding","reception"] },
  { id: "ns-010", name: "Forest Green Soft Silk", category: "silk", price: 8999, color: "Forest Green", fabric: "Soft Silk", image: silk1, gallery: [silk1, silk2, cotton1], description: "Rich forest green soft silk with a contrast pallu.", occasions: ["festive","temple","wedding"] },
  { id: "ns-011", name: "Charcoal Cape Saree", category: "western", price: 12499, color: "Charcoal Grey", fabric: "Satin Crepe", image: western1, gallery: [western1, party1, designer1], description: "Sculptural indo-western piece with an attached cape sleeve.", tag: "new", occasions: ["cocktail","party"] },
  { id: "ns-012", name: "Champagne Sequin Glow", category: "party", price: 9499, color: "Champagne", fabric: "Net with Sequins", image: party1, gallery: [party1, designer1, silk2], description: "All-over sequin saree that catches every light in the room.", occasions: ["party","sangeet","cocktail"] },
  { id: "ns-013", name: "Coral Mul Cotton", category: "cotton", price: 2999, color: "Coral", fabric: "Mul Cotton", image: cotton1, gallery: [cotton1, silk2, designer1], description: "Breezy mul cotton in a fresh coral shade — perfect for warm days.", occasions: ["casual","daywear","office"] },
  { id: "ns-014", name: "Rose Velvet Designer", category: "designer", price: 13999, color: "Rose", fabric: "Velvet & Net", image: designer1, gallery: [designer1, designer2, bridal1], description: "Plush velvet bordered designer saree with embellished pallu.", tag: "bestseller", occasions: ["reception","engagement","wedding"] },
  { id: "ns-015", name: "Sapphire Embroidered Drape", category: "party", price: 8499, color: "Sapphire Blue", fabric: "Georgette", image: party1, gallery: [party1, western1, designer1], description: "Deep sapphire with intricate silver embroidery throughout.", occasions: ["party","cocktail","reception"] },
  { id: "ns-016", name: "Ruby Bridal Lehenga Saree", category: "bridal", price: 22999, oldPrice: 27999, color: "Ruby Red", fabric: "Raw Silk & Velvet", image: bridal1, gallery: [bridal1, designer2, silk1], description: "A pre-stitched bridal lehenga-saree fusion with heritage embroidery.", tag: "limited", occasions: ["wedding","reception"] },
  { id: "ns-017", name: "Mustard Pochampally Silk", category: "silk", price: 7999, color: "Mustard", fabric: "Pochampally Ikat Silk", image: silk2, gallery: [silk2, silk1, cotton1], description: "Handwoven Pochampally ikat in vibrant mustard with geometric motifs.", occasions: ["festive","office","daywear"] },
  { id: "ns-018", name: "Pearl White Pre-Draped Saree", category: "western", price: 11499, color: "Pearl White", fabric: "Satin", image: western1, gallery: [western1, cotton1, party1], description: "A minimalist pearl-white pre-draped indo-western saree.", tag: "new", occasions: ["cocktail","reception","party"] },
  { id: "ns-019", name: "Sage Linen Cotton", category: "cotton", price: 3899, color: "Sage Green", fabric: "Linen Cotton", image: cotton1, gallery: [cotton1, silk1, designer1], description: "Soft sage linen-cotton with hand block printed border.", occasions: ["casual","office","daywear"] },
  { id: "ns-020", name: "Plum Ombre Designer Saree", category: "designer", price: 10999, color: "Plum", fabric: "Chinon Silk", image: designer2, gallery: [designer2, party1, designer1], description: "Stunning plum ombre with sequin pallu and embellished blouse.", occasions: ["sangeet","cocktail","reception"] },
  { id: "ns-021", name: "Royal Gold Tissue Silk", category: "bridal", price: 19999, color: "Gold", fabric: "Tissue Silk", image: silk2, gallery: [silk2, bridal1, designer1], description: "A radiant gold tissue silk bridal saree — fit for a queen.", tag: "bestseller", occasions: ["wedding","reception"] },
] as Product[];

export const featured = products.filter(p => p.tag === "bestseller").slice(0, 6);
export const newArrivals = products.filter(p => p.tag === "new").slice(0, 6);
export const bestSellers = products.filter(p => p.tag === "bestseller");

export function getProduct(id: string) { return products.find(p => p.id === id); }
export function getByCategory(slug: string) { return products.filter(p => p.category === slug); }
export function related(p: Product) { return products.filter(x => x.category === p.category && x.id !== p.id).slice(0, 4); }

// keep pool referenced so unused-image warnings don't fire if rotated
export const _pool = pool;