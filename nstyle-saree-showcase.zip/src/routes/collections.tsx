import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { SiteLayout } from "@/components/site/SiteLayout";
import { SectionTitle } from "@/components/site/SectionTitle";
import { ProductCard } from "@/components/site/ProductCard";
import { categories, products, type CategorySlug } from "@/data/products";

const searchSchema = z.object({
  category: z.string().optional(),
});

export const Route = createFileRoute("/collections")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Collections — N Style Sarees" },
      { name: "description", content: "Shop silk, cotton, bridal, designer, party wear and indo-western sarees at N Style Sarees." },
      { property: "og:title", content: "Collections — N Style Sarees" },
      { property: "og:description", content: "Curated luxury saree collections." },
    ],
  }),
  component: CollectionsPage,
});

function CollectionsPage() {
  const { category } = Route.useSearch();
  const navigate = Route.useNavigate();
  const active = (category as CategorySlug | undefined) ?? "all";
  const list = active === "all" ? products : products.filter(p => p.category === active);

  return (
    <SiteLayout>
      <section className="border-b border-[color:var(--color-gold)]/30 bg-gradient-to-b from-[color:var(--color-maroon)] to-[color:var(--color-maroon-deep)] py-20 text-center text-[color:var(--color-ivory)]">
        <p className="brand-font text-xs text-[color:var(--color-gold)]">OUR ATELIER</p>
        <h1 className="mt-3 font-display text-5xl md:text-6xl gold-gradient-text">Collections</h1>
        <p className="mx-auto mt-4 max-w-xl text-sm text-[color:var(--color-ivory)]/80">From heirloom Kanjivarams to modern indo-western drapes.</p>
      </section>

      <section className="py-12">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={() => navigate({ search: {} })}
              className={`rounded-full px-5 py-2 text-xs font-semibold uppercase tracking-widest transition-all ${active === "all" ? "btn-maroon" : "border border-[color:var(--color-maroon)]/40 text-[color:var(--color-maroon)] hover:bg-[color:var(--color-maroon)]/10"}`}
            >
              All
            </button>
            {categories.map(c => (
              <button
                key={c.slug}
                onClick={() => navigate({ search: { category: c.slug } })}
                className={`rounded-full px-5 py-2 text-xs font-semibold uppercase tracking-widest transition-all ${active === c.slug ? "btn-maroon" : "border border-[color:var(--color-maroon)]/40 text-[color:var(--color-maroon)] hover:bg-[color:var(--color-maroon)]/10"}`}
              >
                {c.name}
              </button>
            ))}
          </div>

          <div className="mt-6 text-center text-sm text-muted-foreground">{list.length} pieces</div>

          <div className="mt-10 grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-4">
            {list.map(p => <ProductCard key={p.id} p={p} />)}
          </div>

          {list.length === 0 && (
            <p className="py-20 text-center text-muted-foreground">No sarees yet in this category.</p>
          )}
        </div>
      </section>
    </SiteLayout>
  );
}