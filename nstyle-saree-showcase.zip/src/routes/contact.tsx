import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { MapPin, Phone, Mail, Instagram, Send } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { BRAND_ADDRESS, BRAND_EMAIL, BRAND_INSTAGRAM, BRAND_PHONE, whatsappGeneralUrl } from "@/lib/whatsapp";
import { toast } from "sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — N Style Sarees" },
      { name: "description", content: "Visit our Chennai boutique, call, or message us on WhatsApp. We'd love to style you." },
      { property: "og:title", content: "Contact — N Style Sarees" },
      { property: "og:description", content: "Get in touch with N Style Sarees." },
    ],
  }),
  component: ContactPage,
});

function ContactPage() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  function submit(e: React.FormEvent) {
    e.preventDefault();
    const text = `Hello N Style Sarees,\n\nName: ${form.name}\nEmail: ${form.email}\n\n${form.message}`;
    window.open(whatsappGeneralUrl(text), "_blank");
    toast.success("Opening WhatsApp to send your message...");
  }
  return (
    <SiteLayout>
      <section className="bg-gradient-to-b from-[color:var(--color-maroon)] to-[color:var(--color-maroon-deep)] py-20 text-center text-[color:var(--color-ivory)]">
        <p className="brand-font text-xs text-[color:var(--color-gold)]">GET IN TOUCH</p>
        <h1 className="mt-3 font-display text-5xl md:text-6xl gold-gradient-text">Contact Us</h1>
        <p className="mx-auto mt-4 max-w-xl text-sm text-[color:var(--color-ivory)]/80">We'd love to help you find your perfect drape.</p>
      </section>

      <section className="py-20">
        <div className="mx-auto grid max-w-6xl grid-cols-1 gap-10 px-6 md:grid-cols-2">
          <div className="space-y-6">
            {[
              { icon: MapPin, label: "Visit Us", value: BRAND_ADDRESS },
              { icon: Phone, label: "Call Us", value: BRAND_PHONE, href: `tel:${BRAND_PHONE.replace(/\s/g, "")}` },
              { icon: Mail, label: "Email Us", value: BRAND_EMAIL, href: `mailto:${BRAND_EMAIL}` },
              { icon: Instagram, label: "Follow Us", value: `@${BRAND_INSTAGRAM}`, href: `https://instagram.com/${BRAND_INSTAGRAM}` },
            ].map((c, i) => (
              <a key={i} href={c.href ?? "#"} target={c.href?.startsWith("http") ? "_blank" : undefined} rel="noreferrer" className="luxury-card luxury-card-hover flex items-start gap-4 rounded-2xl p-5">
                <div className="grid h-12 w-12 flex-none place-items-center rounded-full bg-[color:var(--color-maroon)] text-[color:var(--color-gold-light)]"><c.icon className="h-5 w-5" /></div>
                <div>
                  <p className="brand-font text-xs text-[color:var(--color-gold)]">{c.label.toUpperCase()}</p>
                  <p className="mt-1 text-sm text-[color:var(--color-charcoal)]">{c.value}</p>
                </div>
              </a>
            ))}
          </div>

          <form onSubmit={submit} className="luxury-card rounded-2xl p-7">
            <h2 className="font-display text-2xl text-[color:var(--color-maroon)]">Send a message</h2>
            <p className="mt-1 text-xs text-muted-foreground">We'll respond via WhatsApp within hours.</p>
            <div className="mt-6 space-y-4">
              <input required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your name" className="w-full rounded-lg border border-[color:var(--color-gold)]/30 bg-white px-4 py-3 text-sm outline-none focus:border-[color:var(--color-gold)]" />
              <input required type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="Email address" className="w-full rounded-lg border border-[color:var(--color-gold)]/30 bg-white px-4 py-3 text-sm outline-none focus:border-[color:var(--color-gold)]" />
              <textarea required rows={5} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })} placeholder="Tell us what you're looking for..." className="w-full rounded-lg border border-[color:var(--color-gold)]/30 bg-white px-4 py-3 text-sm outline-none focus:border-[color:var(--color-gold)]" />
              <button type="submit" className="btn-maroon flex w-full items-center justify-center gap-2 rounded-full py-3 text-sm uppercase">
                Send Message <Send className="h-4 w-4" />
              </button>
            </div>
          </form>
        </div>

        <div className="mx-auto mt-16 max-w-6xl px-6">
          <div className="overflow-hidden rounded-2xl border border-[color:var(--color-gold)]/40 shadow-xl">
            <iframe
              title="N Style Sarees on Map"
              src="https://www.google.com/maps?q=Sivaji+Nagar+10th+Street+Tondiarpet+Chennai&output=embed"
              className="h-[400px] w-full"
              loading="lazy"
            />
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}