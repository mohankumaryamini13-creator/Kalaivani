import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Star, Instagram } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { SectionTitle } from "@/components/site/SectionTitle";
import { ProductCard } from "@/components/site/ProductCard";
import { AIRecommender } from "@/components/site/AIRecommender";
import { AIStylist } from "@/components/site/AIStylist";
import { bestSellers, newArrivals, products, categories } from "@/data/products";
import heroImg from "@/assets/hero-1.jpg";
import { BRAND_INSTAGRAM } from "@/lib/whatsapp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "N Style Sarees — Luxury Western Wear Sarees | Chennai" },
      { name: "description", content: "Curated luxury sarees — Silk, Bridal, Designer, Party Wear & Indo-Western. Shop the new collection by N Style Sarees, Chennai." },
      { property: "og:title", content: "N Style Sarees — Luxury Western Wear Sarees" },
      { property: "og:description", content: "Curated luxury sarees by Kalaivani N. Order on WhatsApp." },
    ],
  }),
  component: Home,
});

const reviews = [
  { name: "Anitha R.", text: "The bridal saree was absolutely stunning. Kalaivani was so helpful with styling tips!", rating: 5 },
  { name: "Priya S.", text: "Beautiful quality fabric. Got so many compliments at my reception.", rating: 5 },
  { name: "Divya K.", text: "Love the indo-western collection — perfect for cocktail events.", rating: 5 },
];

function Home() {
  const featured = products.slice(0, 6);
  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[color:var(--color-ivory)] via-[#fdeede] to-[color:var(--color-ivory)]" />
        <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 py-16 md:grid-cols-2 md:py-24">
          <div>
            <p className="brand-font text-xs font-semibold text-[color:var(--color-gold)]">ELEGANT · TRENDY · UNIQUE</p>
            <h1 className="mt-4 font-display text-5xl leading-[1.05] text-[color:var(--color-maroon)] md:text-7xl">
              Drape Yourself <br />in <span className="italic gold-gradient-text">Timeless</span> Luxury
            </h1>
            <p className="mt-6 max-w-md text-base text-[color:var(--color-charcoal)]/80">
              Hand-curated sarees from Chennai's boutique atelier — where heritage weaves meet modern silhouettes.
            </p>
            <div className="mt-8 flex flex-wrap gap-4">
              <Link to="/collections" className="btn-maroon inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm uppercase">
                Shop Collection <ArrowRight className="h-4 w-4" />
              </Link>
              <Link to="/about" className="rounded-full border border-[color:var(--color-maroon)] px-7 py-3.5 text-sm font-medium uppercase tracking-wider text-[color:var(--color-maroon)] transition-colors hover:bg-[color:var(--color-maroon)] hover:text-[color:var(--color-ivory)]">
                Our Story
              </Link>
            </div>
            <div className="mt-12 flex items-center gap-8">
              <div><div className="font-display text-2xl text-[color:var(--color-maroon)]">500+</div><div className="text-xs uppercase tracking-widest text-muted-foreground">Happy Brides</div></div>
              <div className="h-10 w-px bg-[color:var(--color-gold)]/40" />
              <div><div className="font-display text-2xl text-[color:var(--color-maroon)]">100%</div><div className="text-xs uppercase tracking-widest text-muted-foreground">Authentic Weaves</div></div>
              <div className="h-10 w-px bg-[color:var(--color-gold)]/40" />
              <div><div className="font-display text-2xl text-[color:var(--color-maroon)]">PAN</div><div className="text-xs uppercase tracking-widest text-muted-foreground">India Shipping</div></div>
            </div>
          </div>
          <div className="relative">
            <div className="absolute -inset-4 rounded-[2rem] bg-gradient-to-tr from-[color:var(--color-gold)]/30 to-transparent blur-2xl" />
            <div className="relative overflow-hidden rounded-[2rem] border-4 border-[color:var(--color-gold)]/40 shadow-2xl animate-float">
              <img src={heroImg} alt="Luxury saree model in maroon and gold" className="h-[600px] w-full object-cover" width={1080} height={1600} />
            </div>
            <div className="absolute -bottom-6 -left-6 rounded-2xl border border-[color:var(--color-gold)]/40 bg-white/95 px-5 py-4 shadow-xl backdrop-blur">
              <p className="brand-font text-[10px] text-[color:var(--color-gold)]">NEW COLLECTION</p>
              <p className="font-display text-lg text-[color:var(--color-maroon)]">Bridal Couture '26</p>
            </div>
          </div>
        </div>
      </section>

      {/* BRAND INTRO */}
      <section className="bg-[color:var(--color-maroon)] py-16 text-[color:var(--color-ivory)]">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <p className="brand-font text-xs text-[color:var(--color-gold)]">N STYLE SAREES</p>
          <p className="mt-4 font-display text-2xl italic leading-relaxed md:text-3xl">
            "Elegance is not about being noticed — it's about being remembered."
          </p>
          <p className="mt-6 text-sm text-[color:var(--color-ivory)]/80">
            Founded in Chennai by <span className="text-[color:var(--color-gold)]">Kalaivani N</span>, N Style Sarees brings you a curated collection of Indo-Western sarees that blend contemporary style with traditional charm.
          </p>
        </div>
      </section>

      {/* CATEGORIES */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="SHOP BY CATEGORY" title="Our Collections" subtitle="From bridal heirlooms to indo-western statements — find your moment." />
          <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-6">
            {categories.map((c, i) => (
              <Link
                key={c.slug}
                to="/collections"
                search={{ category: c.slug }}
                className="group luxury-card luxury-card-hover overflow-hidden rounded-2xl bg-white p-5 text-center"
              >
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-[color:var(--color-maroon)] to-[color:var(--color-maroon-deep)] text-[color:var(--color-gold-light)] brand-font text-xl">
                  {String(i + 1).padStart(2, "0")}
                </div>
                <h3 className="mt-3 font-display text-base text-[color:var(--color-maroon)]">{c.name}</h3>
                <p className="mt-1 text-[11px] uppercase tracking-widest text-[color:var(--color-gold)]">Explore</p>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* FEATURED */}
      <section className="py-12">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="CURATED FOR YOU" title="Featured Sarees" />
          <div className="grid grid-cols-2 gap-6 md:grid-cols-3 lg:grid-cols-3">
            {featured.map(p => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
      </section>

      {/* NEW ARRIVALS */}
      <section className="bg-white/60 py-20">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="FRESH OFF THE LOOM" title="New Arrivals" />
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {newArrivals.map(p => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
      </section>

      {/* AI Recommender */}
      <AIRecommender />

      {/* BEST SELLERS */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="LOVED BY OUR CUSTOMERS" title="Best Sellers" />
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {bestSellers.map(p => <ProductCard key={p.id} p={p} />)}
          </div>
        </div>
      </section>

      {/* AI Stylist */}
      <AIStylist />

      {/* REVIEWS */}
      <section className="bg-[color:var(--color-ivory)] py-20">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow="WHAT OUR CLIENTS SAY" title="Customer Love" />
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            {reviews.map((r, i) => (
              <div key={i} className="luxury-card rounded-2xl p-7">
                <div className="flex gap-1 text-[color:var(--color-gold)]">
                  {Array.from({ length: r.rating }).map((_, j) => <Star key={j} className="h-4 w-4 fill-current" />)}
                </div>
                <p className="mt-4 font-display italic text-lg text-[color:var(--color-charcoal)]">"{r.text}"</p>
                <p className="mt-4 brand-font text-xs text-[color:var(--color-maroon)]">— {r.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INSTAGRAM */}
      <section className="py-20">
        <div className="mx-auto max-w-7xl px-6">
          <SectionTitle eyebrow={`@${BRAND_INSTAGRAM}`} title="Follow Our Journey" subtitle="Daily styling inspiration, behind-the-scenes & new drops on Instagram." />
          <div className="grid grid-cols-2 gap-3 md:grid-cols-6">
            {products.slice(0, 6).map((p) => (
              <a key={p.id} href={`https://instagram.com/${BRAND_INSTAGRAM}`} target="_blank" rel="noreferrer" className="group relative aspect-square overflow-hidden rounded-xl">
                <img src={p.image} alt={p.name} loading="lazy" className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110" />
                <div className="absolute inset-0 flex items-center justify-center bg-[color:var(--color-maroon)]/0 opacity-0 transition-all group-hover:bg-[color:var(--color-maroon)]/70 group-hover:opacity-100">
                  <Instagram className="h-7 w-7 text-[color:var(--color-gold-light)]" />
                </div>
              </a>
            ))}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}
