import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { MessageCircle, Heart, Truck, ShieldCheck, RefreshCcw, ChevronLeft } from "lucide-react";
import { SiteLayout } from "@/components/site/SiteLayout";
import { ProductCard } from "@/components/site/ProductCard";
import { SectionTitle } from "@/components/site/SectionTitle";
import { getProduct, related, type Product } from "@/data/products";
import { formatINR, whatsappOrderUrl } from "@/lib/whatsapp";

export const Route = createFileRoute("/product/$id")({
  loader: ({ params }) => {
    const p = getProduct(params.id);
    if (!p) throw notFound();
    return p;
  },
  head: ({ loaderData }) => ({
    meta: [
      { title: `${loaderData?.name ?? "Saree"} — N Style Sarees` },
      { name: "description", content: loaderData?.description ?? "" },
      { property: "og:title", content: loaderData?.name ?? "" },
      { property: "og:description", content: loaderData?.description ?? "" },
      { property: "og:image", content: loaderData?.image ?? "" },
    ],
  }),
  notFoundComponent: () => (
    <SiteLayout><div className="py-32 text-center"><h1 className="font-display text-3xl text-[color:var(--color-maroon)]">Saree not found</h1><Link to="/collections" className="mt-4 inline-block text-sm text-[color:var(--color-gold)] underline">Browse collection</Link></div></SiteLayout>
  ),
  component: ProductPage,
});

function ProductPage() {
  const p = Route.useLoaderData() as Product;
  const [img, setImg] = useState(p.image);
  const rel = related(p);

  return (
    <SiteLayout>
      <div className="mx-auto max-w-7xl px-6 py-10">
        <Link to="/collections" className="inline-flex items-center gap-1 text-xs uppercase tracking-widest text-[color:var(--color-maroon)] hover:text-[color:var(--color-gold)]">
          <ChevronLeft className="h-4 w-4" /> Back to collections
        </Link>

        <div className="mt-8 grid grid-cols-1 gap-12 md:grid-cols-2">
          <div>
            <div className="overflow-hidden rounded-2xl border border-[color:var(--color-gold)]/30 bg-white shadow-xl">
              <img src={img} alt={p.name} className="aspect-[3/4] w-full object-cover" />
            </div>
            <div className="mt-4 grid grid-cols-3 gap-3">
              {p.gallery.map((g: string, i: number) => (
                <button key={i} onClick={() => setImg(g)} className={`overflow-hidden rounded-lg border-2 ${g === img ? "border-[color:var(--color-gold)]" : "border-transparent"}`}>
                  <img src={g} alt="thumb" className="aspect-square w-full object-cover" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <p className="brand-font text-xs text-[color:var(--color-gold)]">{p.fabric.toUpperCase()}</p>
            <h1 className="mt-2 font-display text-4xl text-[color:var(--color-maroon)] md:text-5xl">{p.name}</h1>
            <div className="mt-3 flex items-baseline gap-3">
              <span className="font-display text-3xl text-[color:var(--color-maroon)]">{formatINR(p.price)}</span>
              {p.oldPrice && <span className="text-base text-muted-foreground line-through">{formatINR(p.oldPrice)}</span>}
              {p.oldPrice && <span className="rounded-full bg-[color:var(--color-gold)]/20 px-2 py-0.5 text-[10px] font-semibold text-[color:var(--color-maroon)]">SAVE {formatINR(p.oldPrice - p.price)}</span>}
            </div>
            <p className="mt-1 text-xs text-muted-foreground">Inclusive of all taxes. Free shipping across India.</p>

            <div className="my-6 gold-divider" />

            <p className="text-sm leading-relaxed text-[color:var(--color-charcoal)]">{p.description}</p>

            <dl className="mt-6 grid grid-cols-2 gap-4 text-sm">
              <div><dt className="text-xs uppercase tracking-widest text-[color:var(--color-gold)]">Color</dt><dd className="mt-1 text-[color:var(--color-charcoal)]">{p.color}</dd></div>
              <div><dt className="text-xs uppercase tracking-widest text-[color:var(--color-gold)]">Fabric</dt><dd className="mt-1 text-[color:var(--color-charcoal)]">{p.fabric}</dd></div>
              <div><dt className="text-xs uppercase tracking-widest text-[color:var(--color-gold)]">Occasions</dt><dd className="mt-1 capitalize text-[color:var(--color-charcoal)]">{p.occasions.join(", ")}</dd></div>
              <div><dt className="text-xs uppercase tracking-widest text-[color:var(--color-gold)]">SKU</dt><dd className="mt-1 text-[color:var(--color-charcoal)]">{p.id.toUpperCase()}</dd></div>
            </dl>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a href={whatsappOrderUrl(p.name, p.price)} target="_blank" rel="noreferrer" className="flex flex-1 items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-semibold uppercase tracking-wider text-white shadow-lg hover:shadow-xl">
                <MessageCircle className="h-5 w-5" /> Order on WhatsApp
              </a>
              <button className="flex items-center justify-center gap-2 rounded-full border border-[color:var(--color-maroon)] px-6 py-3.5 text-sm font-semibold uppercase tracking-wider text-[color:var(--color-maroon)] hover:bg-[color:var(--color-maroon)]/10">
                <Heart className="h-4 w-4" /> Wishlist
              </button>
            </div>

            <div className="mt-8 grid grid-cols-3 gap-4 border-t border-[color:var(--color-gold)]/20 pt-6 text-center text-xs">
              <div className="flex flex-col items-center gap-1 text-[color:var(--color-charcoal)]"><Truck className="h-5 w-5 text-[color:var(--color-maroon)]" />Free Shipping</div>
              <div className="flex flex-col items-center gap-1 text-[color:var(--color-charcoal)]"><ShieldCheck className="h-5 w-5 text-[color:var(--color-maroon)]" />Authentic Weaves</div>
              <div className="flex flex-col items-center gap-1 text-[color:var(--color-charcoal)]"><RefreshCcw className="h-5 w-5 text-[color:var(--color-maroon)]" />Easy Exchange</div>
            </div>
          </div>
        </div>

        <div className="mt-24">
          <SectionTitle eyebrow="YOU MAY ALSO LOVE" title="Related Sarees" />
          <div className="grid grid-cols-2 gap-6 md:grid-cols-4">
            {rel.map(r => <ProductCard key={r.id} p={r} />)}
          </div>
        </div>
      </div>
    </SiteLayout>
  );
}