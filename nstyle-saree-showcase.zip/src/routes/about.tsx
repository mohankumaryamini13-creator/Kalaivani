import { createFileRoute } from "@tanstack/react-router";
import { SiteLayout } from "@/components/site/SiteLayout";
import { SectionTitle } from "@/components/site/SectionTitle";
import logoCard from "@/assets/logo-card.png";
import hero from "@/assets/hero-1.jpg";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — N Style Sarees" },
      { name: "description", content: "Meet Kalaivani N, founder of N Style Sarees — Chennai's modern luxury saree boutique." },
      { property: "og:title", content: "About — N Style Sarees" },
      { property: "og:description", content: "Founder story and mission." },
    ],
  }),
  component: AboutPage,
});

function AboutPage() {
  return (
    <SiteLayout>
      <section className="bg-gradient-to-b from-[color:var(--color-maroon)] to-[color:var(--color-maroon-deep)] py-20 text-center text-[color:var(--color-ivory)]">
        <p className="brand-font text-xs text-[color:var(--color-gold)]">OUR STORY</p>
        <h1 className="mt-3 font-display text-5xl md:text-6xl gold-gradient-text">About N Style Sarees</h1>
      </section>

      <section className="py-20">
        <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-6 md:grid-cols-2">
          <div className="overflow-hidden rounded-2xl border border-[color:var(--color-gold)]/40 bg-white shadow-xl">
            <img src={logoCard} alt="N Style Sarees brand card" className="w-full" />
          </div>
          <div>
            <p className="brand-font text-xs text-[color:var(--color-gold)]">FOUNDER</p>
            <h2 className="mt-2 font-display text-4xl text-[color:var(--color-maroon)]">Kalaivani N</h2>
            <div className="mt-4 h-px w-20 bg-[color:var(--color-gold)]" />
            <p className="mt-6 leading-relaxed text-[color:var(--color-charcoal)]">
              A Chennai-based curator with a deep love for textiles, Kalaivani founded N Style Sarees to celebrate the modern Indian woman — someone who honours tradition while writing her own story.
            </p>
            <p className="mt-4 leading-relaxed text-[color:var(--color-charcoal)]">
              Every piece in our collection is hand-selected for craftsmanship, quality and that little spark of <em>uniqueness</em>. From Kanjivaram silks woven in Tamil Nadu to contemporary indo-western drapes, our atelier is your destination for sarees that get remembered.
            </p>
            <p className="mt-6 font-display italic text-lg text-[color:var(--color-maroon)]">
              "Thank you for supporting my small business." ♡
            </p>
          </div>
        </div>
      </section>

      <section className="bg-[color:var(--color-maroon)] py-20 text-[color:var(--color-ivory)]">
        <div className="mx-auto max-w-5xl px-6">
          <SectionTitle eyebrow="OUR PHILOSOPHY" title="Mission & Vision" />
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <div className="rounded-2xl border border-[color:var(--color-gold)]/30 bg-black/20 p-8 backdrop-blur">
              <h3 className="brand-font text-[color:var(--color-gold)]">MISSION</h3>
              <p className="mt-4 leading-relaxed">
                To make luxury saree shopping personal, joyful and accessible — bringing handpicked indo-western and heritage weaves directly to the modern woman, wherever she is.
              </p>
            </div>
            <div className="rounded-2xl border border-[color:var(--color-gold)]/30 bg-black/20 p-8 backdrop-blur">
              <h3 className="brand-font text-[color:var(--color-gold)]">VISION</h3>
              <p className="mt-4 leading-relaxed">
                To be India's most-loved boutique for contemporary saree drapes — a brand where every customer feels styled, seen and celebrated.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20">
        <div className="mx-auto max-w-6xl px-6">
          <SectionTitle eyebrow="WHY CHOOSE US" title="The N Style Promise" />
          <div className="grid grid-cols-2 gap-6 md:grid-cols-5">
            {["Elegant Craftsmanship","Trendy & Modern Styles","Hand-Curated Collections","Premium Quality Fabrics","Indo-Western Fusion"].map((t, i) => (
              <div key={i} className="luxury-card luxury-card-hover rounded-2xl p-6 text-center">
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[color:var(--color-maroon)] brand-font text-[color:var(--color-gold-light)]">{i + 1}</div>
                <p className="mt-3 text-sm font-semibold text-[color:var(--color-charcoal)]">{t}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
      {/* Keep hero referenced to avoid unused import warnings on strict TS */}
      <link rel="preload" as="image" href={hero} />
    </SiteLayout>
  );
}