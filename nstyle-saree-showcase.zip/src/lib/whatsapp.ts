export const WHATSAPP_NUMBER = "919080908541";
export const BRAND_PHONE = "+91 9080908541";
export const BRAND_EMAIL = "nathuzwesternwearsaree@gmail.com";
export const BRAND_INSTAGRAM = "nathu_western_saree";
export const BRAND_ADDRESS = "No. 197, Sivaji Nagar, 10th Street, Tondiarpet, Chennai – 600081";

export function whatsappOrderUrl(productName: string, price: number) {
  const msg = `Hello N Style Sarees,\n\nI would like to order this saree.\n\nProduct Name: ${productName}\nPrice: ₹${price.toLocaleString("en-IN")}\n\nCustomer Name:\nPhone Number:\nDelivery Address:\n\nPlease confirm availability.`;
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
}

export function whatsappGeneralUrl(text = "Hello N Style Sarees, I'd like to know more about your collection.") {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`;
}

export function formatINR(n: number) {
  return `₹${n.toLocaleString("en-IN")}`;
}